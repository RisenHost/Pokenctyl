import React from 'react';
import { motion } from 'framer-motion';
import './styles.css';
import Logo from './assets/logo.svg';

export default function App() {
  return (
    <div className="app-root">
      <div className="bg-animated" />
      <motion.div className="login-card" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
        <img src={Logo} className="logo" alt="Pokenctyl" />
        <h1>Welcome to Pokenctyl</h1>
        <p className="subtitle">Modern panel • nebula + nook theme • animated login</p>

        <form className="login-form" onSubmit={(e) => { e.preventDefault(); alert('Demo login — check backend for admin user (admin@pokenctyl.local)'); }}>
          <input placeholder="Email" required />
          <input placeholder="Password" type="password" required />
          <button type="submit" className="primary">Sign In</button>
        </form>
      </motion.div>

      <div className="credits">Pokenctyl © 2025-26</div>
    </div>
  );
}
