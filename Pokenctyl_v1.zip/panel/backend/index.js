const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 8080;
const DB = {
  host: process.env.DB_HOST || 'db',
  user: process.env.DB_USER || 'pokenctyl',
  password: process.env.DB_PASS || 'pokenctyl123',
  database: process.env.DB_NAME || 'pokenctyl'
};

let pool;
(async function init() {
  pool = await mysql.createPool({ host: DB.host, user: DB.user, password: DB.password, database: DB.database, waitForConnections: true });
  // create tables if not exist
  await pool.query(`CREATE TABLE IF NOT EXISTS daemons (id VARCHAR(64) PRIMARY KEY, token VARCHAR(128), hostname VARCHAR(128), ip VARCHAR(64), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS users (id VARCHAR(64) PRIMARY KEY, email VARCHAR(128), password VARCHAR(128), role VARCHAR(32), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  // default admin user (unsafe default — change in production)
  const [rows] = await pool.query(`SELECT * FROM users WHERE email = ?`, ['admin@pokenctyl.local']);
  if (rows.length === 0) {
    await pool.query(`INSERT INTO users (id,email,password,role) VALUES (?,?,?,?)`, [uuidv4(),'admin@pokenctyl.local','P0kenAdmin!','admin']);
  }
})();

app.get('/', (req, res) => res.json({ ok: true, message: 'Pokenctyl backend running' }));

// daemon registration endpoint (simple)
app.post('/api/daemons/register', async (req, res) => {
  const { token, hostname, ip } = req.body || {};
  if (!token) return res.status(400).json({ error: 'missing token' });
  // in this simple example token is accepted and registered
  const id = uuidv4();
  await pool.query(`INSERT INTO daemons (id, token, hostname, ip) VALUES (?,?,?,?)`, [id, token, hostname || 'unknown', ip || '127.0.0.1']);
  return res.json({ ok: true, id });
});

app.listen(PORT, () => console.log(`Pokenctyl backend listening on ${PORT}`));
